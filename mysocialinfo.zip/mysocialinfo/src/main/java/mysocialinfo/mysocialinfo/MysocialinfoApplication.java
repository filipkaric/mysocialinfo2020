package mysocialinfo.mysocialinfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MysocialinfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MysocialinfoApplication.class, args);
	}

}
